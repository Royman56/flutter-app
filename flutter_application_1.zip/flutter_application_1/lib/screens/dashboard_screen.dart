import 'package:flutter/material.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Map<String, dynamic>> locations = [];
  int _selectedIndex = 0;

  // Método para cambiar la página actual cuando se selecciona un ícono en la barra inferior.
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard de Ventas'),
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: <Widget>[
          Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: locations.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(locations[index]['locationName']),
                      subtitle: Text(
                          'Lat: ${locations[index]['latitude']}, Lng: ${locations[index]['longitude']}'),
                    );
                  },
                ),
              ),
            ],
          ),
          Center(
            child: ElevatedButton(
              onPressed: () {
                // Navegación al mapa, pasando la lista de ubicaciones
                Navigator.pushNamed(context, '/map', arguments: locations);
              },
              child: Text('Ver Mapa'),
            ),
          ),
          Center(
            child: ElevatedButton(
              onPressed: () {
                // Navegación al mapa, pasando la lista de ubicaciones
                Navigator.pushNamed(context, '/statistics', arguments: locations);
              },
              child: Text('Ver estadisticas'),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: 'Ubicaciones',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: 'Mapas',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pie_chart),
            label: 'Estadísticas',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton(
              onPressed: () async {
                final newLocation = await Navigator.pushNamed(
                    context, '/register-location');

                if (newLocation != null && newLocation is Map<String, dynamic>) {
                  setState(() {
                    locations.add(newLocation);
                  });
                }
              },
              child: Icon(Icons.add),
              backgroundColor: Colors.blue,
              tooltip: 'Registrar Nueva Ubicación',
            )
          : null, // El botón flotante aparece solo en la vista de Ubicaciones
    );
  }
}