import 'package:flutter/material.dart';
import 'simple_bar_chart.dart'; // Asegúrate de importar la clase SimpleBarChart

class StatisticsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Datos de ejemplo para el gráfico
    final List<String> xAxisList = ["Enero", "Febrero", "Marzo", "Abril"];
    final List<double> yAxisList = [30, 42, 54, 20];
    final String xAxisName = "Meses";
    final String yAxisName = "Ventas";
    final double interval = 10;

    return Scaffold(
      appBar: AppBar(
        title: Text('Estadísticas de Ventas'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SimpleBarChart(
          xAxisList: xAxisList,
          yAxisList: yAxisList,
          xAxisName: xAxisName,
          yAxisName: yAxisName,
          interval: interval,
        ),
      ),
    );
  }
}
