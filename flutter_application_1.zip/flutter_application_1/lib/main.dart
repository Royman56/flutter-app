import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';
import 'screens/register_location_screen.dart';
import 'screens/map_screen.dart';
import 'screens/statistics_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestión de POS',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => DashboardScreen(),
        '/register-location': (context) => RegisterLocationScreen(),
        '/statistics': (context) => StatisticsScreen(), // Añadir esta línea si no está
      },
      // Aquí usamos 'onGenerateRoute' para pasar las ubicaciones al mapa.
      onGenerateRoute: (settings) {
        if (settings.name == '/map') {
          final args = settings.arguments as List<Map<String, dynamic>>;

          return MaterialPageRoute(
            builder: (context) {
              return MapScreen(locations: args);
            },
          );
        }
        return null;
      },
    );
  }
}